const express = require('express');
const cors = require('cors');
const { ResourceManager } = require('./traffic_system');
const { DeadlockDetector } = require('./deadlock');
const { insertVehicleData, checkSpeedViolation, getVehicleStats } = require('./database');

const app = express();
const port = 3000;

// Configure CORS with specific options
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type'],
    credentials: true,
    maxAge: 86400 // 24 hours
}));

app.use(express.json({ limit: '1mb' }));

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Server error:', err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// Test endpoint with timeout
app.get('/api/test', async (req, res) => {
    try {
        // Set a timeout for the response
        res.setTimeout(5000, () => {
            res.status(408).json({ error: 'Request timeout' });
        });
        
        res.json({ status: 'Server is running!' });
    } catch (error) {
        console.error('Test endpoint error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Initialize resource manager and deadlock detector
const resourceManager = new ResourceManager();
const deadlockDetector = new DeadlockDetector();

// New endpoint to get vehicle statistics
app.get('/api/vehicle-stats', async (req, res) => {
    try {
        res.setTimeout(5000, () => {
            res.status(408).json({ error: 'Request timeout' });
        });

        getVehicleStats((err, rows) => {
            if (err) {
                console.error('Error getting vehicle stats:', err);
                return res.status(500).json({ error: err.message });
            }
            res.json(rows);
        });
    } catch (error) {
        console.error('Vehicle stats error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Update the check-resources endpoint to include speed monitoring
app.post('/api/check-resources', async (req, res) => {
    try {
        res.setTimeout(5000, () => {
            res.status(408).json({ error: 'Request timeout' });
        });

        const { vehicleId, requestedResources } = req.body;
        if (!vehicleId || !requestedResources) {
            return res.status(400).json({ error: 'Missing required parameters' });
        }

        // Insert vehicle data into database
        insertVehicleData({
            id: vehicleId,
            speed: requestedResources.speed || 0,
            direction: requestedResources.direction,
            x: requestedResources.position.x,
            y: requestedResources.position.y
        });

        // Check for speed violations
        const violation = checkSpeedViolation({
            id: vehicleId,
            speed: requestedResources.speed || 0
        });

        const isSafe = resourceManager.isSafeAllocation(vehicleId, requestedResources);
        res.json({ 
            isSafe,
            violation: violation.isViolation ? {
                excessSpeed: violation.excessSpeed,
                fineAmount: violation.fineAmount
            } : null
        });
    } catch (error) {
        console.error('Resource check error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Endpoint to check for deadlocks with timeout
app.post('/api/check-deadlock', async (req, res) => {
    try {
        res.setTimeout(5000, () => {
            res.status(408).json({ error: 'Request timeout' });
        });

        const { vehicles, resources } = req.body;
        if (!vehicles || !resources) {
            return res.status(400).json({ error: 'Missing required parameters' });
        }

        const deadlockInfo = deadlockDetector.checkDeadlock(vehicles, resources);
        res.json(deadlockInfo);
    } catch (error) {
        console.error('Deadlock check error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Endpoint to update resource state with timeout
app.post('/api/update-resources', async (req, res) => {
    try {
        res.setTimeout(5000, () => {
            res.status(408).json({ error: 'Request timeout' });
        });

        const { vehicleId, resources } = req.body;
        if (!vehicleId || !resources) {
            return res.status(400).json({ error: 'Missing required parameters' });
        }

        resourceManager.updateResources(vehicleId, resources);
        res.json({ success: true });
    } catch (error) {
        console.error('Resource update error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Start server with error handling
const server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

server.on('error', (error) => {
    console.error('Server error:', error);
    if (error.code === 'EADDRINUSE') {
        console.error(`Port ${port} is already in use`);
    }
}); 