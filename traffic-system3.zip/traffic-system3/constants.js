// Traffic System Constants
const STOP_DISTANCE = 80;
const SAFE_DISTANCE = 45;
const ROAD_WIDTH = 100;

// Make constants available globally
window.STOP_DISTANCE = STOP_DISTANCE;
window.SAFE_DISTANCE = SAFE_DISTANCE;
window.ROAD_WIDTH = ROAD_WIDTH; 