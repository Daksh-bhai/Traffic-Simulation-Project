-- Add last_updated column to vehicles table
ALTER TABLE vehicles
ADD COLUMN last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Update existing records to have last_updated equal to created_at
UPDATE vehicles 
SET last_updated = created_at 
WHERE last_updated IS NULL; 