const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Create database connection
const db = new sqlite3.Database(path.join(__dirname, 'traffic.db'), (err) => {
    if (err) {
        console.error('Error connecting to database:', err);
    } else {
        console.log('Connected to SQLite database');
        createTables();
    }
});

// Create necessary tables
function createTables() {
    db.serialize(() => {
        // Vehicles table
        db.run(`CREATE TABLE IF NOT EXISTS vehicles (
            id TEXT PRIMARY KEY,
            speed REAL,
            direction TEXT,
            position_x REAL,
            position_y REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Violations table
        db.run(`CREATE TABLE IF NOT EXISTS violations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id TEXT,
            speed REAL,
            fine_amount REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
        )`);
    });
}

// Insert vehicle data
function insertVehicleData(vehicle) {
    const stmt = db.prepare(`
        INSERT INTO vehicles (id, speed, direction, position_x, position_y)
        VALUES (?, ?, ?, ?, ?)
    `);
    stmt.run(vehicle.id, vehicle.speed, vehicle.direction, vehicle.x, vehicle.y);
    stmt.finalize();
}

// Check for speed violations and insert if found
function checkSpeedViolation(vehicle) {
    const SPEED_LIMIT = 3; // Adjust this value based on your simulation
    const FINE_PER_UNIT = 100; // Fine amount per unit over speed limit

    if (vehicle.speed > SPEED_LIMIT) {
        const excessSpeed = vehicle.speed - SPEED_LIMIT;
        const fineAmount = excessSpeed * FINE_PER_UNIT;

        const stmt = db.prepare(`
            INSERT INTO violations (vehicle_id, speed, fine_amount)
            VALUES (?, ?, ?)
        `);
        stmt.run(vehicle.id, vehicle.speed, fineAmount);
        stmt.finalize();

        return {
            isViolation: true,
            excessSpeed,
            fineAmount
        };
    }

    return { isViolation: false };
}

// Get vehicle statistics
function getVehicleStats(callback) {
    db.all(`
        SELECT 
            v.id,
            v.speed,
            v.direction,
            v.position_x,
            v.position_y,
            v.timestamp,
            COUNT(vio.id) as violation_count,
            SUM(vio.fine_amount) as total_fines
        FROM vehicles v
        LEFT JOIN violations vio ON v.id = vio.vehicle_id
        GROUP BY v.id
        ORDER BY v.timestamp DESC
    `, callback);
}

module.exports = {
    db,
    insertVehicleData,
    checkSpeedViolation,
    getVehicleStats
}; 