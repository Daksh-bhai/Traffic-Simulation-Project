const express = require('express');
const cors = require('cors');
const { ResourceManager } = require('./traffic_system');
const { DeadlockDetector } = require('./deadlock');

const app = express();
const port = 3000;

// Configure CORS
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type']
}));

app.use(express.json());

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// Test endpoint
app.get('/api/test', (req, res) => {
    try {
        res.json({ status: 'Server is running!' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Initialize resource manager and deadlock detector
const resourceManager = new ResourceManager();
const deadlockDetector = new DeadlockDetector();

// Endpoint to check resource allocation
app.post('/api/check-resources', (req, res) => {
    try {
        const { vehicleId, requestedResources } = req.body;
        const isSafe = resourceManager.isSafeAllocation(vehicleId, requestedResources);
        res.json({ isSafe });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Endpoint to check for deadlocks
app.post('/api/check-deadlock', (req, res) => {
    try {
        const { vehicles, resources } = req.body;
        const deadlockInfo = deadlockDetector.checkDeadlock(vehicles, resources);
        res.json(deadlockInfo);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Endpoint to update resource state
app.post('/api/update-resources', (req, res) => {
    try {
        const { vehicleId, resources } = req.body;
        resourceManager.updateResources(vehicleId, resources);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
}); 