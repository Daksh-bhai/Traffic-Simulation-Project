let intersection;
let vehicles = [];
let isRunning = false;
let serverConnected = false;

// Test server connection
async function testServerConnection() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

        const response = await fetch('http://localhost:3000/api/test', {
            signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Server connection test:', data);
        serverConnected = true;
        return true;
    } catch (error) {
        console.error('Server connection failed:', error);
        serverConnected = false;
        return false;
    }
}

window.onload = async function () {
    // Test server connection on load
    await testServerConnection();
    
    document.getElementById('start').addEventListener('click', () => {
        if (!serverConnected) {
            alert('Server connection failed! Please check if the server is running.');
            return;
        }
        isRunning = true;
        loop();
    });

    document.getElementById('stop').addEventListener('click', () => {
        isRunning = false;
        noLoop();
    });
};

class Vehicle {
  constructor(x, y, speed, color, direction) {
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.color = color;
    this.direction = direction;
    this.turning = false;
    this.turnDirection = null;
    this.angle = 0;
    this.id = Math.random().toString(36).substr(2, 9);
  }

  async move(intersection, vehicleList) {
    const light = intersection.lights.find(l =>
      (this.direction === "horizontal" && l.direction === "horizontal") ||
      (this.direction === "vertical" && l.direction === "vertical")
    );

    const dx = this.x - intersection.x;
    const dy = this.y - intersection.y;
    const margin = 15;
    const approaching = this.direction === "horizontal"
      ? (Math.abs(dx) < STOP_DISTANCE && Math.abs(dx) > margin)
      : (Math.abs(dy) < STOP_DISTANCE && Math.abs(dy) > margin);

    if (approaching && serverConnected) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000);

            const response = await fetch('http://localhost:3000/api/check-resources', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    vehicleId: this.id,
                    requestedResources: {
                        direction: this.direction,
                        position: { x: this.x, y: this.y }
                    }
                }),
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const { isSafe } = await response.json();
            if (!isSafe) {
                return; // Stop if allocation is not safe
            }
        } catch (error) {
            if (error.name === 'AbortError') {
                console.error('Resource check timed out');
            } else {
                console.error('Error checking resources:', error);
            }
            return; // Stop on error
        }
    }

    const crossed = this.direction === "horizontal" ? dx > margin : dy > margin;
    if (approaching && light.state === "red" && !this.turning && !crossed) return;

    if (!this.turning && Math.abs(dx) < 5 && Math.abs(dy) < 5) {
      if (random() < 0.5) {
        this.turning = true;
        this.turnDirection = random(["left", "right"]);
      }
    }

    if (this.turning) {
      this.handleTurning();
    } else {
      const frontVehicle = this.findFrontVehicle(vehicleList);
      if (frontVehicle && this.isTooClose(frontVehicle)) return;
      this.moveStraight();
    }
  }

  moveStraight() {
    if (this.direction === "horizontal") {
      this.x += this.speed;
      if (this.x > width + 50) this.x = -50;
    } else {
      this.y += this.speed;
      if (this.y > height + 50) this.y = -50;
    }
  }

  handleTurning() {
    const turnSpeed = this.speed;

    if (this.direction === "horizontal") {
      this.x += turnSpeed;
      this.y += (this.turnDirection === "left" ? -turnSpeed : turnSpeed);
      if (abs(this.y - height / 2) > 30) {
        this.direction = "vertical";
        this.turning = false;
      }
    } else {
      this.y += turnSpeed;
      this.x += (this.turnDirection === "left" ? turnSpeed : -turnSpeed);
      if (abs(this.x - width / 2) > 30) {
        this.direction = "horizontal";
        this.turning = false;
      }
    }
  }

  findFrontVehicle(vehicleList) {
    let closest = null;
    let minDistance = Infinity;

    for (const other of vehicleList) {
      if (other === this || other.direction !== this.direction) continue;

      if (this.direction === "horizontal") {
        const ahead = other.x > this.x;
        const sameLane = abs(this.y - other.y) < 5;
        const dist = other.x - this.x;
        if (ahead && sameLane && dist < minDistance) {
          minDistance = dist;
          closest = other;
        }
      } else {
        const ahead = other.y > this.y;
        const sameLane = abs(this.x - other.x) < 5;
        const dist = other.y - this.y;
        if (ahead && sameLane && dist < minDistance) {
          minDistance = dist;
          closest = other;
        }
      }
    }

    return closest;
  }

  isTooClose(other) {
    return this.direction === "horizontal"
      ? (other.x - this.x) < SAFE_DISTANCE
      : (other.y - this.y) < SAFE_DISTANCE;
  }

  draw() {
    fill(this.color);
    if (this.direction === "horizontal") {
      rect(this.x, this.y - 10, 30, 20);
    } else {
      rect(this.x - 10, this.y, 20, 30);
    }
  }
}

class TrafficLight {
  constructor(x, y, direction) {
    this.x = x;
    this.y = y;
    this.state = "red";
    this.direction = direction;
  }

  draw() {
    fill(this.state === "red" ? "#ff0000" : "#00ff00");
    circle(this.x, this.y, 36);
    fill(50);
    rect(this.x - 5, this.y, 10, 50);
  }
}

class Intersection {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.activeDirection = "horizontal";
    this.timer = 0;
    this.lights = [
      new TrafficLight(x - 100, y, "horizontal"),
      new TrafficLight(x + 100, y, "horizontal"),
      new TrafficLight(x, y - 100, "vertical"),
      new TrafficLight(x, y + 100, "vertical")
    ];
  }

  update(vehicleList) {
    const hCount = this.countVehicles(vehicleList, "horizontal");
    const vCount = this.countVehicles(vehicleList, "vertical");

    this.timer++;
    const minGreen = 60;
    const maxGreen = 240;

    if (
      (this.activeDirection === "horizontal" && this.timer > minGreen && (vCount > hCount || this.timer > maxGreen)) ||
      (this.activeDirection === "vertical" && this.timer > minGreen && (hCount > vCount || this.timer > maxGreen))
    ) {
      this.activeDirection = this.activeDirection === "horizontal" ? "vertical" : "horizontal";
      this.timer = 0;
    }

    this.lights.forEach(light => {
      light.state = (light.direction === this.activeDirection) ? "green" : "red";
    });
  }

  countVehicles(vehicleList, direction) {
    let count = 0;
    for (const v of vehicleList) {
      if (v.direction !== direction || v.turning) continue;
      const dx = abs(v.x - this.x);
      const dy = abs(v.y - this.y);
      if (
        direction === "horizontal" && v.x < this.x - 10 && dx < STOP_DISTANCE && abs(v.y - this.y) < ROAD_WIDTH / 2
      ) {
        count++;
      } else if (
        direction === "vertical" && v.y < this.y - 10 && dy < STOP_DISTANCE && abs(v.x - this.x) < ROAD_WIDTH / 2
      ) {
        count++;
      }
    }
    return count;
  }

  draw() {
    fill(70);
    rect(this.x - 50, this.y - 50, 100, 100);
    this.lights.forEach(light => light.draw());
  }
}

function setup() {
  const canvas = createCanvas(1000, 800);
  canvas.parent('canvas-container');

  intersection = new Intersection(width / 2, height / 2);

  vehicles = [
    new Vehicle(100, height / 2 - 10, 2, color(255, 0, 0), "horizontal"),
    new Vehicle(width / 2 - 10, 100, 2, color(0, 0, 255), "vertical")
  ];
}

async function checkDeadlock() {
    if (!serverConnected) return;

    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        const response = await fetch('http://localhost:3000/api/check-deadlock', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                vehicles: vehicles.map(v => ({
                    id: v.id,
                    direction: v.direction,
                    position: { x: v.x, y: v.y }
                })),
                resources: {
                    intersection: {
                        x: intersection.x,
                        y: intersection.y
                    }
                }
            }),
            signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const deadlockInfo = await response.json();
        if (deadlockInfo.deadlock) {
            console.warn('Deadlock detected:', deadlockInfo);
        }
    } catch (error) {
        if (error.name === 'AbortError') {
            console.error('Deadlock check timed out');
        } else {
            console.error('Error checking deadlock:', error);
        }
    }
}

function draw() {
  background(220);

  if (frameCount % 120 === 0 && vehicles.length < 25) {
    const dir = random(["horizontal", "vertical"]);
    if (dir === "horizontal") {
      vehicles.push(new Vehicle(-30, height / 2 - 10, 2, color(random(255), 0, 0), "horizontal"));
    } else {
      vehicles.push(new Vehicle(width / 2 - 10, -30, 2, color(0, 0, random(255)), "vertical"));
    }
  }

  fill(50);
  rect(0, height / 2 - ROAD_WIDTH / 2, width, ROAD_WIDTH);
  rect(width / 2 - ROAD_WIDTH / 2, 0, ROAD_WIDTH, height);

  drawRoadMarkings();

  intersection.update(vehicles);
  intersection.draw();

  const mainLight = intersection.lights[0];
  document.getElementById("light-status").textContent =
    mainLight.state.charAt(0).toUpperCase() + mainLight.state.slice(1);

  vehicles.forEach(v => {
    v.move(intersection, vehicles);
    v.draw();
  });

  document.getElementById("vehicle-count").textContent = vehicles.length;

  // Check for deadlocks every 60 frames
  if (frameCount % 60 === 0) {
    checkDeadlock();
  }
}

function drawRoadMarkings() {
  fill(255);
  for (let x = 0; x < width; x += 40) {
    rect(x, height / 2 - 12, 20, 24);
  }
  for (let y = 0; y < height; y += 40) {
    rect(width / 2 - 12, y, 24, 20);
  }
}
