// Remove constant declarations since they're in constants.js
class TrafficSystemVehicle {
  constructor(x, y, speed, color, direction) {
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.color = color;
    this.direction = direction;
    this.turning = false;
    this.turnDirection = null;
    this.angle = 0;
  }

  move(intersection, vehicleList) {
    const light = intersection.lights.find(l =>
      (this.direction === "horizontal" && l.direction === "horizontal") ||
      (this.direction === "vertical" && l.direction === "vertical")
    );

    const dx = this.x - intersection.x;
    const dy = this.y - intersection.y;
    const margin = 15;
    const approaching = this.direction === "horizontal"
      ? (Math.abs(dx) < STOP_DISTANCE && Math.abs(dx) > margin)
      : (Math.abs(dy) < STOP_DISTANCE && Math.abs(dy) > margin);

    const crossed = this.direction === "horizontal" ? dx > margin : dy > margin;
    if (approaching && light.state === "red" && !this.turning && !crossed) return;

    if (!this.turning && Math.abs(dx) < 5 && Math.abs(dy) < 5) {
      if (random() < 0.5) {
        this.turning = true;
        this.turnDirection = random(["left", "right"]);
      }
    }

    if (this.turning) {
      this.handleTurning();
    } else {
      const frontVehicle = this.findFrontVehicle(vehicleList);
      if (frontVehicle && this.isTooClose(frontVehicle)) return;
      this.moveStraight();
    }
  }

  moveStraight() {
    if (this.direction === "horizontal") {
      this.x += this.speed;
      if (this.x > width + 50) this.x = -50;
    } else {
      this.y += this.speed;
      if (this.y > height + 50) this.y = -50;
    }
  }

  handleTurning() {
    const turnSpeed = this.speed;

    if (this.direction === "horizontal") {
      this.x += turnSpeed;
      this.y += (this.turnDirection === "left" ? -turnSpeed : turnSpeed);
      if (abs(this.y - height / 2) > 30) {
        this.direction = "vertical";
        this.turning = false;
      }
    } else {
      this.y += turnSpeed;
      this.x += (this.turnDirection === "left" ? turnSpeed : -turnSpeed);
      if (abs(this.x - width / 2) > 30) {
        this.direction = "horizontal";
        this.turning = false;
      }
    }
  }

  findFrontVehicle(vehicleList) {
    let closest = null;
    let minDistance = Infinity;

    for (const other of vehicleList) {
      if (other === this || other.direction !== this.direction) continue;

      if (this.direction === "horizontal") {
        const ahead = other.x > this.x;
        const sameLane = abs(this.y - other.y) < 5;
        const dist = other.x - this.x;
        if (ahead && sameLane && dist < minDistance) {
          minDistance = dist;
          closest = other;
        }
      } else {
        const ahead = other.y > this.y;
        const sameLane = abs(this.x - other.x) < 5;
        const dist = other.y - this.y;
        if (ahead && sameLane && dist < minDistance) {
          minDistance = dist;
          closest = other;
        }
      }
    }

    return closest;
  }

  isTooClose(other) {
    return this.direction === "horizontal"
      ? (other.x - this.x) < SAFE_DISTANCE
      : (other.y - this.y) < SAFE_DISTANCE;
  }

  draw() {
    fill(this.color);
    if (this.direction === "horizontal") {
      rect(this.x, this.y - 10, 30, 20);
    } else {
      rect(this.x - 10, this.y, 20, 30);
    }
  }
}

class TrafficSystemTrafficLight {
  constructor(x, y, direction) {
    this.x = x;
    this.y = y;
    this.state = "red";
    this.direction = direction;
  }

  draw() {
    fill(this.state === "red" ? "#ff0000" : "#00ff00");
    circle(this.x, this.y, 36);
    fill(50);
    rect(this.x - 5, this.y, 10, 50);
  }
}

class TrafficSystemIntersection {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.activeDirection = "horizontal";
    this.timer = 0;
    this.lights = [
      new TrafficSystemTrafficLight(x - 100, y, "horizontal"),
      new TrafficSystemTrafficLight(x + 100, y, "horizontal"),
      new TrafficSystemTrafficLight(x, y - 100, "vertical"),
      new TrafficSystemTrafficLight(x, y + 100, "vertical")
    ];
  }

  update(vehicleList) {
    const hCount = this.countVehicles(vehicleList, "horizontal");
    const vCount = this.countVehicles(vehicleList, "vertical");

    this.timer++;
    const minGreen = 60;
    const maxGreen = 240;

    if (
      (this.activeDirection === "horizontal" && this.timer > minGreen && (vCount > hCount || this.timer > maxGreen)) ||
      (this.activeDirection === "vertical" && this.timer > minGreen && (hCount > vCount || this.timer > maxGreen))
    ) {
      this.activeDirection = this.activeDirection === "horizontal" ? "vertical" : "horizontal";
      this.timer = 0;
    }

    this.lights.forEach(light => {
      light.state = (light.direction === this.activeDirection) ? "green" : "red";
    });
  }

  countVehicles(vehicleList, direction) {
    let count = 0;
    for (const v of vehicleList) {
      if (v.direction !== direction || v.turning) continue;
      const dx = abs(v.x - this.x);
      const dy = abs(v.y - this.y);
      if (
        direction === "horizontal" && v.x < this.x - 10 && dx < STOP_DISTANCE && abs(v.y - this.y) < ROAD_WIDTH / 2
      ) {
        count++;
      } else if (
        direction === "vertical" && v.y < this.y - 10 && dy < STOP_DISTANCE && abs(v.x - this.x) < ROAD_WIDTH / 2
      ) {
        count++;
      }
    }
    return count;
  }

  draw() {
    fill(70);
    rect(this.x - 50, this.y - 50, 100, 100);
    this.lights.forEach(light => light.draw());
  }
}

class ResourceManager {
    constructor() {
        this.available = {
            horizontal: 1,  // One lane per direction
            vertical: 1
        };
        this.allocated = new Map();  // vehicleId -> resources
        this.maxNeeds = new Map();   // vehicleId -> max resources needed
    }

    isSafeAllocation(vehicleId, requestedResources) {
        // Check if requested resources are available
        if (requestedResources.direction === 'horizontal' && this.available.horizontal < 1) {
            return false;
        }
        if (requestedResources.direction === 'vertical' && this.available.vertical < 1) {
            return false;
        }

        // Simulate allocation
        const tempAvailable = { ...this.available };
        if (requestedResources.direction === 'horizontal') {
            tempAvailable.horizontal--;
        } else {
            tempAvailable.vertical--;
        }

        // Check if this allocation would lead to a safe state
        return this.isSafeState(vehicleId, tempAvailable);
    }

    isSafeState(vehicleId, available) {
        const work = { ...available };
        const finish = new Map();

        // Initialize finish array
        for (const [id] of this.allocated) {
            finish.set(id, false);
        }

        // Find a process that can be allocated resources
        let found = true;
        while (found) {
            found = false;
            for (const [id, allocated] of this.allocated) {
                if (!finish.get(id)) {
                    const canAllocate = this.canAllocateResources(id, work);
                    if (canAllocate) {
                        // Simulate process completion
                        work.horizontal += allocated.horizontal || 0;
                        work.vertical += allocated.vertical || 0;
                        finish.set(id, true);
                        found = true;
                    }
                }
            }
        }

        // Check if all processes finished
        return Array.from(finish.values()).every(f => f);
    }

    canAllocateResources(vehicleId, available) {
        const allocated = this.allocated.get(vehicleId) || { horizontal: 0, vertical: 0 };
        const maxNeeded = this.maxNeeds.get(vehicleId) || { horizontal: 1, vertical: 1 };
        
        const needed = {
            horizontal: maxNeeded.horizontal - allocated.horizontal,
            vertical: maxNeeded.vertical - allocated.vertical
        };

        return needed.horizontal <= available.horizontal && 
               needed.vertical <= available.vertical;
    }

    updateResources(vehicleId, resources) {
        if (!this.allocated.has(vehicleId)) {
            this.allocated.set(vehicleId, { horizontal: 0, vertical: 0 });
            this.maxNeeds.set(vehicleId, { horizontal: 1, vertical: 1 });
        }

        const current = this.allocated.get(vehicleId);
        
        // Update available resources
        if (current.horizontal > 0) this.available.horizontal++;
        if (current.vertical > 0) this.available.vertical--;

        // Update allocated resources
        this.allocated.set(vehicleId, {
            horizontal: resources.direction === 'horizontal' ? 1 : 0,
            vertical: resources.direction === 'vertical' ? 1 : 0
        });
    }
}

// Universal export pattern
if (typeof window !== 'undefined') {
  window.TrafficSystemVehicle = TrafficSystemVehicle;
  window.TrafficSystemTrafficLight = TrafficSystemTrafficLight;
  window.TrafficSystemIntersection = TrafficSystemIntersection;
  window.ResourceManager = ResourceManager;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    TrafficSystemVehicle,
    TrafficSystemTrafficLight,
    TrafficSystemIntersection,
    ResourceManager
  };
}
